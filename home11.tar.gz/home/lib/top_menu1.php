<html>
    <head>
<style>
@font-face {
    font-family: 'NEXON Lv2 Gothic';
    src: url('https://cdn.jsdelivr.net/gh/projectnoonnu/noonfonts_20-04@2.1/NEXON Lv2 Gothic.woff') format('woff');
    font-weight: normal;
    font-style: normal;
}
ul {
    list-style-type: none;
    background-color: #09131A;
    height: 40px;
    width: 102.7%;
}
li a {
    display: block;
    color: white;
    padding: 10px 8px;
    margin-left: 155px;
    font-family: 'NEXON Lv2 Gothic';
    font-size: 20px;
}
li a:hover {
    color: white;
    font-size: 23px;
}
</style>
<ul>
<li><a href="./memo/memo.php">낙서장</a></li>
<li><a href="./greet/list.php">가입인사</a></li>
<li><a href="./concert/list.php">연주회 소개</a></li>
<li><a href="./download/list.php">자료실</a></li>
<li><a href="./free/list.php">자유게시판</a></li>
<li><a href="./qna/list.php">레슨문의</a></li>
<li><a href="#" onclick="window.open('./survey/survey.php', '','scrollbars=no, toolbars=no,width=180,height=230')" border="0">설문조사</a></li>
</ul>
    </head>
</html>
